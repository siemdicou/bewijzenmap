<div id="navigation">
	<ul class="menu">	
		<li><a href="<?php echo DIR;?>" target="_blank">View Website</a></li>
		<li><a href="<?php echo DIRADMIN;?>?logout">Logout</a></li>
	</ul>
</div>
<a href="index.php?lang=dutch"><div class="country">
	<img src="../img/nl.png">
	<h1>Nederlands</h1>
</div></a>

<a href="index.php?lang=english"><div class="country">
	<img src="../img/en.png">
	<h1>English</h1>
</div></a>	