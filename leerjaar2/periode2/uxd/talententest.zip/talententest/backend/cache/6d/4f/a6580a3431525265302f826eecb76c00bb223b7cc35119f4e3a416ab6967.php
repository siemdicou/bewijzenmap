<?php

/* occupations/edit.html */
class __TwigTemplate_6d4fa6580a3431525265302f826eecb76c00bb223b7cc35119f4e3a416ab6967 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Beroepen <small>beroep wijzigen</small></h1>
            <ol class=\"breadcrumb\">
                <li><i class=\"fa fa-dashboard\"></i> Beroepen</li>
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> wijzigen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">

            ";
        // line 15
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "POST")) {
            // line 16
            echo "            <div class=\"panel panel-success\">
                <div class=\"panel-heading\">
                <h3 class=\"panel-title\">Beroep gewijzigd!</h3>
                </div>
                <div class=\"panel-body\">
                    Titel: ";
            // line 21
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_occupation_, "name"), "html", null, true);
            echo " <br/>
                    Beschrijving: ";
            // line 22
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo $this->getAttribute($_new_occupation_, "description");
            echo " <br/>
                    Youtube: <a href=\"http://www.youtube.com/watch?v=";
            // line 23
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_occupation_, "youtube"), "html", null, true);
            echo "\">http://www.youtube.com/watch?v=";
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_occupation_, "youtube"), "html", null, true);
            echo "</a> <br/>
                    Niveau: ";
            // line 24
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($_new_occupation_, "educationLevel"), "name"), "html", null, true);
            echo " <br/>
                    Talent: ";
            // line 25
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($_new_occupation_, "talent"), "name"), "html", null, true);
            echo " <br/>
                </div>
            </div>
            <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_overview"), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                <i class=\"fa fa-dashboard\"></i> Overzicht
            </a>
            <a href=\"";
            // line 31
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_edit", array("id" => $this->getAttribute($_new_occupation_, "id"))), "html", null, true);
            echo "\" class=\"btn btn-info\">
                <i class=\"fa fa-edit\"></i> Wijzig
            </a>
            <a href=\"";
            // line 34
            if (isset($context["new_occupation"])) { $_new_occupation_ = $context["new_occupation"]; } else { $_new_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_delete", array("id" => $this->getAttribute($_new_occupation_, "id"))), "html", null, true);
            echo "\" class=\"btn btn-danger\">
                <i class=\"fa fa-edit\"></i> Verwijder
            </a>
            ";
        }
        // line 38
        echo "
            ";
        // line 39
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "GET")) {
            // line 40
            echo "            <form class=\"form-horizontal\" method=\"POST\" action=\"";
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_edit", array("id" => $this->getAttribute($_occupation_, "id"))), "html", null, true);
            echo "\">
            <fieldset>

            <!-- Text input-->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"title\">Titel</label>
              <div class=\"col-md-8\">
              <input id=\"title\" name=\"title\" type=\"text\" value=\"";
            // line 47
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_occupation_, "name"), "html", null, true);
            echo "\" class=\"form-control input-md\" required=\"\">

              </div>
            </div>

            <!-- Textarea -->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"description\">Beschrijving</label>
              <div class=\"col-md-8\">
                <textarea class=\"form-control\" rows=\"10\" id=\"ckeditor\" name=\"description\">";
            // line 56
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_occupation_, "description"), "html", null, true);
            echo "</textarea>
              </div>
            </div>

            <!-- Text input-->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"yt-video\">Youtube video</label>
              <div class=\"col-md-8\">
              <input id=\"yt-video\" name=\"yt-video\" type=\"text\" value=\"http://www.youtube.com/watch?v=";
            // line 64
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_occupation_, "youtube"), "html", null, true);
            echo "\" class=\"form-control input-md\" required=\"\">

              </div>
            </div>

            <!-- Multiple Radios -->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"talent\">Talent</label>
              <div class=\"col-md-4\">
              ";
            // line 73
            if (isset($context["talents"])) { $_talents_ = $context["talents"]; } else { $_talents_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($_talents_);
            foreach ($context['_seq'] as $context["_key"] => $context["talent"]) {
                // line 74
                echo "              <div class=\"radio\">
                <label for=\"talent-";
                // line 75
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "id"), "html", null, true);
                echo "\">
                  <input type=\"radio\" name=\"talent\" id=\"talent-";
                // line 76
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "id"), "html", null, true);
                echo "\" value=\"";
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "id"), "html", null, true);
                echo "\" ";
                if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                if (($this->getAttribute($this->getAttribute($_occupation_, "talent"), "id") == $this->getAttribute($_talent_, "id"))) {
                    echo " checked=\"checked\"";
                }
                echo ">
                  ";
                // line 77
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "name"), "html", null, true);
                echo "
                </label>
                </div>
              ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['talent'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 81
            echo "              </div>
            </div>

            <!-- Multiple Radios -->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"educationlevel\">Niveau</label>
              <div class=\"col-md-4\">
              ";
            // line 88
            if (isset($context["education_levels"])) { $_education_levels_ = $context["education_levels"]; } else { $_education_levels_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($_education_levels_);
            foreach ($context['_seq'] as $context["_key"] => $context["level"]) {
                // line 89
                echo "              <div class=\"radio\">
                <label for=\"educationlevel-";
                // line 90
                if (isset($context["level"])) { $_level_ = $context["level"]; } else { $_level_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_level_, "id"), "html", null, true);
                echo "\">
                  <input type=\"radio\" name=\"educationlevel\" id=\"educationlevel-";
                // line 91
                if (isset($context["level"])) { $_level_ = $context["level"]; } else { $_level_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_level_, "id"), "html", null, true);
                echo "\" value=\"";
                if (isset($context["level"])) { $_level_ = $context["level"]; } else { $_level_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_level_, "id"), "html", null, true);
                echo "\" ";
                if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
                if (isset($context["level"])) { $_level_ = $context["level"]; } else { $_level_ = null; }
                if (($this->getAttribute($this->getAttribute($_occupation_, "educationLevel"), "id") == $this->getAttribute($_level_, "id"))) {
                    echo " checked=\"checked\"";
                }
                echo ">
                  ";
                // line 92
                if (isset($context["level"])) { $_level_ = $context["level"]; } else { $_level_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_level_, "name"), "html", null, true);
                echo "
                </label>
                </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['level'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 96
            echo "              </div>
            </div>

            <div class=\"form-group\">
                <div class=\"col-md-2 control-label\">
                    <button type=\"submit\" class=\"btn btn-success\">
                        <i class=\"fa fa-edit\"></i> Wijzig
                    </button>
                </div>
            </div>
            </fieldset>
            </form>
            ";
        }
        // line 109
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "occupations/edit.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 109,  246 => 96,  235 => 92,  221 => 91,  216 => 90,  213 => 89,  208 => 88,  199 => 81,  188 => 77,  174 => 76,  169 => 75,  166 => 74,  161 => 73,  148 => 64,  136 => 56,  123 => 47,  111 => 40,  108 => 39,  105 => 38,  97 => 34,  90 => 31,  84 => 28,  77 => 25,  72 => 24,  64 => 23,  59 => 22,  54 => 21,  47 => 16,  44 => 15,  31 => 4,  28 => 3,);
    }
}
