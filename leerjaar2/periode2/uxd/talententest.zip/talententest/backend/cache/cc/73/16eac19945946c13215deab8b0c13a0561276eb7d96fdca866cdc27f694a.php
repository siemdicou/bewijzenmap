<?php

/* schools/edit.html */
class __TwigTemplate_cc7316eac19945946c13215deab8b0c13a0561276eb7d96fdca866cdc27f694a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>scholen <small>school wijzigen</small></h1>
            <ol class=\"breadcrumb\">
                <li><i class=\"fa fa-dashboard\"></i> scholen</li>
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> wijzigen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">

            ";
        // line 15
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "POST")) {
            // line 16
            echo "            <div class=\"panel panel-success\">
                <div class=\"panel-heading\">
                <h3 class=\"panel-title\">school gewijzigd!</h3>
                </div>
                <div class=\"panel-body\">
                    Naam: ";
            // line 21
            if (isset($context["new_school"])) { $_new_school_ = $context["new_school"]; } else { $_new_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_school_, "name"), "html", null, true);
            echo " <br/>
                </div>
            </div>
            <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_overview"), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                <i class=\"fa fa-dashboard\"></i> Overzicht
            </a>
            <a href=\"";
            // line 27
            if (isset($context["new_school"])) { $_new_school_ = $context["new_school"]; } else { $_new_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_edit", array("id" => $this->getAttribute($_new_school_, "id"))), "html", null, true);
            echo "\" class=\"btn btn-info\">
                <i class=\"fa fa-edit\"></i> Wijzig
            </a>
            <a href=\"";
            // line 30
            if (isset($context["new_school"])) { $_new_school_ = $context["new_school"]; } else { $_new_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_delete", array("id" => $this->getAttribute($_new_school_, "id"))), "html", null, true);
            echo "\" class=\"btn btn-danger\">
                <i class=\"fa fa-edit\"></i> Verwijder
            </a>
            ";
        }
        // line 34
        echo "
            ";
        // line 35
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "GET")) {
            // line 36
            echo "            <form class=\"form-horizontal\" method=\"POST\" action=\"";
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_edit", array("id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\">
            <fieldset>

            <!-- Text input-->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"title\">Titel</label>
              <div class=\"col-md-8\">
              <input id=\"title\" name=\"name\" type=\"text\" value=\"";
            // line 43
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "\" class=\"form-control input-md\" required=\"\">

              </div>
            </div>

            <div class=\"form-group\">
                <div class=\"col-md-2 control-label\">
                    <button type=\"submit\" class=\"btn btn-success\">
                        <i class=\"fa fa-edit\"></i> Wijzig
                    </button>
                </div>
            </div>
            </fieldset>
            </form>
            ";
        }
        // line 58
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "schools/edit.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 58,  100 => 43,  88 => 36,  85 => 35,  82 => 34,  74 => 30,  67 => 27,  61 => 24,  54 => 21,  47 => 16,  44 => 15,  31 => 4,  28 => 3,);
    }
}
