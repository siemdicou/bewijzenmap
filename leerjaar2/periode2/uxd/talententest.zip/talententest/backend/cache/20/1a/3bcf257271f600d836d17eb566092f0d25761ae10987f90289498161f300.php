<?php

/* talents/overview.html */
class __TwigTemplate_201a3bcf257271f600d836d17eb566092f0d25761ae10987f90289498161f300 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Talenten <small>talenten overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Talenten</li>
            </ol>
        </div>
        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 21
        if (isset($context["talents"])) { $_talents_ = $context["talents"]; } else { $_talents_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_talents_);
        foreach ($context['_seq'] as $context["_key"] => $context["talent"]) {
            // line 22
            echo "                    <tr>
                        <td>
                            ";
            // line 24
            if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 27
            if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("talents_edit", array("id" => $this->getAttribute($_talent_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['talent'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "talents/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 31,  66 => 27,  59 => 24,  55 => 22,  50 => 21,  31 => 4,  28 => 3,);
    }
}
