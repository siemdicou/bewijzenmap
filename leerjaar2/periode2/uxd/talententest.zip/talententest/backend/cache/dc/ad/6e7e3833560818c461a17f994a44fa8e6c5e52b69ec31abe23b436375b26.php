<?php

/* talents/edit.html */
class __TwigTemplate_dcad6e7e3833560818c461a17f994a44fa8e6c5e52b69ec31abe23b436375b26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Talenten <small>talenten wijzigen</small></h1>
            <ol class=\"breadcrumb\">
                <li><i class=\"fa fa-dashboard\"></i> Talenten</li>
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Talenten wijzigen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            ";
        // line 14
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "POST")) {
            // line 15
            echo "
                <div class=\"panel panel-success\">
                    <div class=\"panel-heading\">
                    <h3 class=\"panel-title\">Talent gewijzigd!</h3>
                    </div>
                    <div class=\"panel-body\">
                        Talent: ";
            // line 21
            if (isset($context["new_talent"])) { $_new_talent_ = $context["new_talent"]; } else { $_new_talent_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_talent_, "name"), "html", null, true);
            echo " <br/>
                        Vragen:<br/>
                        <ol>
                        ";
            // line 24
            if (isset($context["new_talent"])) { $_new_talent_ = $context["new_talent"]; } else { $_new_talent_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($_new_talent_, "questions"));
            foreach ($context['_seq'] as $context["_key"] => $context["question"]) {
                // line 25
                echo "                            <li>";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_question_, "question"), "html", null, true);
                echo "</li>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['question'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "                        </ol>
                    </div>
                </div>

                <a href=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("talents_overview"), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                    <i class=\"fa fa-dashboard\"></i> Overzicht
                </a>
                <a href=\"";
            // line 34
            if (isset($context["new_talent"])) { $_new_talent_ = $context["new_talent"]; } else { $_new_talent_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("talents_edit", array("id" => $this->getAttribute($_new_talent_, "id"))), "html", null, true);
            echo "\" class=\"btn btn-info\">
                    <i class=\"fa fa-edit\"></i> Wijzig
                </a>

            ";
        }
        // line 39
        echo "            ";
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "GET")) {
            // line 40
            echo "            <form class=\"form-horizontal\" method=\"POST\" action=\"";
            if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("talents_edit", array("id" => $this->getAttribute($_talent_, "id"))), "html", null, true);
            echo "\">
            <fieldset>

            <!-- Form Name -->
            <legend>";
            // line 44
            if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "name"), "html", null, true);
            echo "</legend>

            ";
            // line 46
            if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($_talent_, "questions"));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["question"]) {
                // line 47
                echo "            <!-- Text input-->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"textinput\">Vraag ";
                // line 49
                if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_loop_, "index"), "html", null, true);
                echo "</label>
              <div class=\"col-md-8\">
              <input id=\"textinput\" name=\"question[";
                // line 51
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_question_, "id"), "html", null, true);
                echo "]\" type=\"text\" value=\"";
                if (isset($context["question"])) { $_question_ = $context["question"]; } else { $_question_ = null; }
                echo twig_escape_filter($this->env, $this->getAttribute($_question_, "question"), "html", null, true);
                echo "\" class=\"form-control input-md\" required=\"required\">

              </div>
            </div>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['question'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 56
            echo "
            <!-- Button (Double) -->
            <div class=\"form-group\">
              <label class=\"col-md-2 control-label\" for=\"button1id\"></label>
              <div class=\"col-md-8\">
                <button id=\"button1id\" name=\"button1id\" class=\"btn btn-success\">Opslaan</button>
                <button id=\"button2id\" name=\"button2id\" class=\"btn btn-danger\">Annuleren</button>
              </div>
            </div>

            </fieldset>
            </form>
            ";
        }
        // line 69
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "talents/edit.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  182 => 69,  167 => 56,  144 => 51,  138 => 49,  134 => 47,  116 => 46,  110 => 44,  101 => 40,  97 => 39,  88 => 34,  82 => 31,  76 => 27,  66 => 25,  61 => 24,  54 => 21,  46 => 15,  43 => 14,  31 => 4,  28 => 3,);
    }
}
