<?php

/* dashboard.html */
class __TwigTemplate_fea428a2258508795b001e4195a91da6e57abed3e7862606a50bae3ebe972db5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'extrajs' => array($this, 'block_extrajs'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-users fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["total_users"]) ? $context["total_users"] : null), "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Gebruikers</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("users_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-suitcase fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["total_occupations"]) ? $context["total_occupations"] : null), "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Beroepen</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-university fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 69
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["schools"]) ? $context["schools"] : null)), "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Scholen</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-12\">

  <form class=\"form-horizontal\" role=\"form\">
    <div class=\"form-group\">
      <label class=\"col-sm-6 control-label\">Filter op school: </label>
      <div class=\"col-sm-6\">
        <select class=\"form-control\" onchange=\"window.location.href=this.value\">
            <option value=\"\">Geen</option>
          ";
        // line 97
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["schools"]) ? $context["schools"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["school"]) {
            // line 98
            echo "            <option value=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("dashboard", array("school_id" => $this->getAttribute((isset($context["school"]) ? $context["school"] : null), "id"))), "html", null, true);
            echo "\" ";
            if (((isset($context["active_school_id"]) ? $context["active_school_id"] : null) == $this->getAttribute((isset($context["school"]) ? $context["school"] : null), "id"))) {
                echo " selected ";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["school"]) ? $context["school"] : null), "name"), "html", null, true);
            echo "</option>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['school'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "        </select>
      </div>
    </div>
  </form>
</div>

<div class=\"col-lg-12\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Geregistreerde gebruikers</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"user-activity\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen talenten</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-talents-donut\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen vaardigheden</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-skills-donut\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen Schooladviezen</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-schooladvices\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Geslacht gebruikers</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"donut-users-gender\"></div>
    </div>
  </div>
</div>

";
    }

    // line 163
    public function block_extrajs($context, array $blocks = array())
    {
        // line 164
        echo "<script>
\$(document).ready(function(){
    Morris.Bar({
        element: 'most-picked-talents-donut',
        data: JSON.parse('";
        // line 168
        echo twig_jsonencode_filter((isset($context["most_picked_talents"]) ? $context["most_picked_talents"] : null));
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 35,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Bar({
        element: 'most-picked-skills-donut',
        data: JSON.parse('";
        // line 185
        echo twig_jsonencode_filter((isset($context["most_picked_skills"]) ? $context["most_picked_skills"] : null));
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 45,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Bar({
        element: 'most-picked-schooladvices',
        data: JSON.parse('";
        // line 202
        echo twig_jsonencode_filter((isset($context["most_schooladvices"]) ? $context["most_schooladvices"] : null));
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 45,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Area({
        element: 'user-activity',
        data: JSON.parse('";
        // line 219
        echo twig_jsonencode_filter($this->getAttribute((isset($context["users"]) ? $context["users"] : null), "created_by_day"));
        echo "'),
        xkey: 'day',
        ykeys: ['amount'],
        labels: ['hoeveelheid'],
        pointSize: 2,
        hideHover: 'auto'
      });

    Morris.Donut({
      element: 'donut-users-gender',
      data: JSON.parse('";
        // line 229
        echo twig_jsonencode_filter((isset($context["users_gender"]) ? $context["users_gender"] : null));
        echo "'),
      formatter: function (y) {
        var total = this.data[0].value + this.data[1].value;
        return Math.round((y / total * 100) * 100) / 100 + \"%\";
      }
    });
});
</script>
";
    }

    public function getTemplateName()
    {
        return "dashboard.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 229,  298 => 219,  278 => 202,  258 => 185,  238 => 168,  232 => 164,  229 => 163,  164 => 100,  149 => 98,  145 => 97,  119 => 74,  111 => 69,  85 => 46,  77 => 41,  51 => 18,  43 => 13,  32 => 4,  29 => 3,);
    }
}
