<?php

/* login.html */
class __TwigTemplate_9bc134251d4f352d4c399810412ff6a1840d1fee611aa277233478af46a3ec03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'navigation' => array($this, 'block_navigation'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_navigation($context, array $blocks = array())
    {
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"col-lg-6 col-lg-offset-2\">
      <form class=\"form-signin\" role=\"form\" method=\"POST\" action=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("login"), "html", null, true);
        echo "\">
        <h2 class=\"form-signin-heading\">Login</h2>
        <div class=\"form-group ";
        // line 10
        if ((isset($context["error"]) ? $context["error"] : null)) {
            echo " has-error ";
        }
        echo "\">
            <input type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Gebruikersnaam\" required autofocus>
        </div>
        <div class=\"form-group ";
        // line 13
        if ((isset($context["error"]) ? $context["error"] : null)) {
            echo " has-error ";
        }
        echo "\">
            <input name=\"password\" type=\"password\" class=\"form-control\" placeholder=\"Wachtwoord\" required>
            <p class=\"help-block\">";
        // line 15
        echo twig_escape_filter($this->env, (isset($context["error"]) ? $context["error"] : null), "html", null, true);
        echo "</p>
        </div>
        <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Inloggen</button>
      </form>
    </div>

";
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 15,  53 => 13,  45 => 10,  40 => 8,  37 => 7,  34 => 6,  29 => 3,);
    }
}
