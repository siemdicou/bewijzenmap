<?php

/* skills/overview.html */
class __TwigTemplate_4df7fa352456a4b93e36183a8417ac266967da42ca1ea8698e3eb5719b8a6f2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>vaardigheden <small>vaardigheden overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> vaardigheden</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <p>
                <a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_new"), "html", null, true);
        echo "\" class=\"btn btn-success\">
                    <i class=\"fa fa-plus\"></i> Toevoegen
                </a>
            </p>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 30
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["skills"]) ? $context["skills"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["skill"]) {
            // line 31
            echo "                    <tr>
                        <td>
                            ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["skill"]) ? $context["skill"] : null), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_edit", array("id" => $this->getAttribute((isset($context["skill"]) ? $context["skill"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                            <a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_delete", array("id" => $this->getAttribute((isset($context["skill"]) ? $context["skill"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-trash-o\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['skill'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "skills/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 41,  80 => 37,  76 => 36,  70 => 33,  66 => 31,  62 => 30,  43 => 14,  31 => 4,  28 => 3,);
    }
}
