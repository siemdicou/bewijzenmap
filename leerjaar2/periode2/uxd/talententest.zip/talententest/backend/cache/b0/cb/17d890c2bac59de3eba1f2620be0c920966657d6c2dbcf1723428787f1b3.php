<?php

/* schools/overview.html */
class __TwigTemplate_b0cb17d890c2bac59de3eba1f2620be0c920966657d6c2dbcf1723428787f1b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Scholen <small>Scholen overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-university\"></i> Scholen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <p>
                <a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_new"), "html", null, true);
        echo "\" class=\"btn btn-success\">
                    <i class=\"fa fa-plus\"></i> Toevoegen
                </a>
            </p>
        </div>
        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Gebruikers <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></i></th>
                        </tr>
                    </thead>
                <tbody>

                    ";
        // line 31
        if (isset($context["schools"])) { $_schools_ = $context["schools"]; } else { $_schools_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_schools_);
        foreach ($context['_seq'] as $context["_key"] => $context["school"]) {
            // line 32
            echo "                    <tr>
                        <td>
                            ";
            // line 34
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 37
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, twig_length_filter($this->env, $this->getAttribute($_school_, "user")), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 40
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_edit", array("id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                            <a href=\"";
            // line 41
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_delete", array("id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-trash-o\"></i></a>
                            <a href=\"";
            // line 42
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("dashboard", array("school_id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-tasks\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['school'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "schools/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 46,  96 => 42,  91 => 41,  86 => 40,  79 => 37,  72 => 34,  68 => 32,  63 => 31,  43 => 14,  31 => 4,  28 => 3,);
    }
}
