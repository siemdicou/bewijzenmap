<?php

/* occupations/overview.html */
class __TwigTemplate_4a5de997ffffbf88ec992c350b35546a9a647f46579b0643afd8e0b6306d2373 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Beroepen <small>beroepen overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Beroepen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <p>
                <a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_new"), "html", null, true);
        echo "\" class=\"btn btn-success\">
                    <i class=\"fa fa-plus\"></i> Toevoegen
                </a>
            </p>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Niveau <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Talent <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Laatst aangepast <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 33
        if (isset($context["occupations"])) { $_occupations_ = $context["occupations"]; } else { $_occupations_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_occupations_);
        foreach ($context['_seq'] as $context["_key"] => $context["occupation"]) {
            // line 34
            echo "                    <tr>
                        <td>
                            ";
            // line 36
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_occupation_, "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 39
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($_occupation_, "education_level"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 42
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($_occupation_, "talent"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 45
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($_occupation_, "updated_at"), "H:i d/m/y"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 48
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_edit", array("id" => $this->getAttribute($_occupation_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                            <a href=\"";
            // line 49
            if (isset($context["occupation"])) { $_occupation_ = $context["occupation"]; } else { $_occupation_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_delete", array("id" => $this->getAttribute($_occupation_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-trash-o\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['occupation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "occupations/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 53,  107 => 49,  102 => 48,  95 => 45,  88 => 42,  81 => 39,  74 => 36,  70 => 34,  65 => 33,  43 => 14,  31 => 4,  28 => 3,);
    }
}
