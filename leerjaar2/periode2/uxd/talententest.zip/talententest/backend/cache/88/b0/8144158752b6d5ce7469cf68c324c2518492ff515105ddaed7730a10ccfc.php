<?php

/* base.html */
class __TwigTemplate_88b08144158752b6d5ce7469cf68c324c2518492ff515105ddaed7730a10ccfc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'navigation' => array($this, 'block_navigation'),
            'content' => array($this, 'block_content'),
            'extrajs' => array($this, 'block_extrajs'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <base href=\"";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "\" target=\"_self\">

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Talententest Admin</title>

    <!-- Bootstrap core CSS -->
    <link href=\"css/bootstrap.css\" rel=\"stylesheet\">

    <!-- Add custom CSS here -->
    <link href=\"css/sb-admin.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"font-awesome/css/font-awesome.min.css\">
    <!-- Page Specific CSS -->
    <link rel=\"stylesheet\" href=\"http://cdn.oesmith.co.uk/morris-0.4.3.min.css\">
  </head>

  <body>

    <div id=\"wrapper\">
    ";
        // line 26
        $this->displayBlock('navigation', $context, $blocks);
        // line 52
        echo "      <div id=\"page-wrapper\">
      ";
        // line 53
        $this->displayBlock('content', $context, $blocks);
        // line 56
        echo "
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src=\"js/jquery-1.10.2.js\"></script>
    <script src=\"js/bootstrap.js\"></script>

    <!-- Page Specific Plugins -->
    <script src=\"http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js\"></script>
    <script src=\"http://cdn.oesmith.co.uk/morris-0.4.3.min.js\"></script>
    <script src=\"js/morris/chart-data-morris.js\"></script>
<!--     <script src=\"js/flot/jquery.flot.js\"></script>
    <script src=\"js/flot/jquery.flot.pie.js\"></script>
    <script src=\"js/flot/jquery.flot.resize.js\"></script>
    <script src=\"js/flot/jquery.flot.tooltip.min.js\"></script> -->
    <script src=\"js/tablesorter/jquery.tablesorter.js\"></script>
    <script src=\"js/tablesorter/tables.js\"></script>
    <script src=\"ckeditor/ckeditor.js\"></script>
    <script type=\"text/javascript\">
        CKEDITOR.replace( 'ckeditor' );
    </script>
    ";
        // line 79
        $this->displayBlock('extrajs', $context, $blocks);
        // line 80
        echo "  </body>
</html>
";
    }

    // line 26
    public function block_navigation($context, array $blocks = array())
    {
        // line 27
        echo "      <!-- Sidebar -->
      <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-ex1-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["base_url"]) ? $context["base_url"] : null), "html", null, true);
        echo "\">Project Paspoort - Talententest Admin</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse navbar-ex1-collapse\">
          <ul class=\"nav navbar-nav side-nav\">
            ";
        // line 43
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mainmenu"]) ? $context["mainmenu"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
            // line 44
            echo "                <li";
            if (($this->env->getExtension('slim')->urlFor($this->getAttribute((isset($context["menu"]) ? $context["menu"] : null), "url")) == (isset($context["current_url"]) ? $context["current_url"] : null))) {
                echo " class=\"active\"";
            }
            echo ">
                  <a href=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor($this->getAttribute((isset($context["menu"]) ? $context["menu"] : null), "url")), "html", null, true);
            echo "\"><i class=\"fa ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["menu"]) ? $context["menu"] : null), "icon"), "html", null, true);
            echo "\"></i> ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["menu"]) ? $context["menu"] : null), "title"), "html", null, true);
            echo "</a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
    ";
    }

    // line 53
    public function block_content($context, array $blocks = array())
    {
        // line 54
        echo "
      ";
    }

    // line 79
    public function block_extrajs($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "base.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 79,  150 => 54,  147 => 53,  140 => 48,  127 => 45,  120 => 44,  116 => 43,  107 => 37,  95 => 27,  92 => 26,  86 => 80,  84 => 79,  59 => 56,  57 => 53,  54 => 52,  52 => 26,  27 => 4,  22 => 1,  111 => 53,  101 => 49,  97 => 48,  91 => 45,  85 => 42,  79 => 39,  73 => 36,  69 => 34,  65 => 33,  43 => 14,  31 => 4,  28 => 3,);
    }
}
