<?php

/* users/overview.html */
class __TwigTemplate_af5112dc039e65046497afbd958471c166205c458030f24d7f8c85ff2678d744 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Gebruikers <small>gebruikers overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Gebruikers</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Nickname <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">School <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Geslacht <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Gemaakt op <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Talenten <i class=\"fa fa-sort\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 25
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) ? $context["users"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 26
            echo "                    <tr>
                        <td>
                            ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "nickname"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "school"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <i class=\"fa fa-";
            // line 34
            echo ((($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "gender") == "m")) ? ("male") : ("female"));
            echo "\" style=\"color:";
            echo ((($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "gender") == "m")) ? ("#08004F") : ("#6D00B5"));
            echo "\"></i>
                            <p style=\"display:none\">";
            // line 35
            echo ((($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "gender") == "m")) ? ("male") : ("female"));
            echo "</p>
                        </td>
                        <td>
                            ";
            // line 38
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : null), "created_at"), "d/m/y"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 41
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(twig_sort_filter($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "talents")));
            foreach ($context['_seq'] as $context["_key"] => $context["talent"]) {
                // line 42
                echo "                                 ";
                if (($this->getAttribute($this->getAttribute((isset($context["talent"]) ? $context["talent"] : null), "pivot"), "picked") == 1)) {
                    // line 43
                    echo "                                    ";
                    echo twig_escape_filter($this->env, $this->getAttribute((isset($context["talent"]) ? $context["talent"] : null), "name"), "html", null, true);
                    echo ",
                                 ";
                }
                // line 45
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['talent'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "users/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 49,  111 => 46,  105 => 45,  99 => 43,  96 => 42,  92 => 41,  86 => 38,  80 => 35,  74 => 34,  68 => 31,  62 => 28,  58 => 26,  54 => 25,  31 => 4,  28 => 3,);
    }
}
