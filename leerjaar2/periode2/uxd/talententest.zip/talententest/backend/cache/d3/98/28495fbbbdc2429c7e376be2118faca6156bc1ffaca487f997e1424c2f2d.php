<?php

/* dashboard.html */
class __TwigTemplate_d39828495fbbbdc2429c7e376be2118faca6156bc1ffaca487f997e1424c2f2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'extrajs' => array($this, 'block_extrajs'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-users fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 13
        if (isset($context["total_users"])) { $_total_users_ = $context["total_users"]; } else { $_total_users_ = null; }
        echo twig_escape_filter($this->env, $_total_users_, "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Gebruikers</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("users_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-suitcase fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 41
        if (isset($context["total_occupations"])) { $_total_occupations_ = $context["total_occupations"]; } else { $_total_occupations_ = null; }
        echo twig_escape_filter($this->env, $_total_occupations_, "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Beroepen</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-3\">
    <div class=\"panel panel-success\">
      <div class=\"panel-heading\">
        <div class=\"row\">
          <div class=\"col-xs-6\">
            <i class=\"fa fa-university fa-5x\"></i>
          </div>
          <div class=\"col-xs-6 text-right\">
            <p class=\"announcement-heading\">";
        // line 69
        if (isset($context["schools"])) { $_schools_ = $context["schools"]; } else { $_schools_ = null; }
        echo twig_escape_filter($this->env, twig_length_filter($this->env, $_schools_), "html", null, true);
        echo "</p>
            <p class=\"announcement-text\">Scholen</p>
          </div>
        </div>
      </div>
      <a href=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_overview"), "html", null, true);
        echo "\">
        <div class=\"panel-footer announcement-bottom\">
          <div class=\"row\">
            <div class=\"col-xs-6\">
                Overzicht
            </div>
            <div class=\"col-xs-6 text-right\">
              <i class=\"fa fa-arrow-circle-right\"></i>
            </div>
          </div>
        </div>
      </a>
    </div>
</div>

<div class=\"col-lg-12\">

  <form class=\"form-horizontal\" role=\"form\">
    <div class=\"form-group\">
      <label class=\"col-sm-6 control-label\">Filter op school: </label>
      <div class=\"col-sm-6\">
        <select class=\"form-control\" onchange=\"window.location.href=this.value\">
            <option value=\"\">Geen</option>
          ";
        // line 97
        if (isset($context["schools"])) { $_schools_ = $context["schools"]; } else { $_schools_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_schools_);
        foreach ($context['_seq'] as $context["_key"] => $context["school"]) {
            // line 98
            echo "            <option value=\"";
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("dashboard", array("school_id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\" ";
            if (isset($context["active_school_id"])) { $_active_school_id_ = $context["active_school_id"]; } else { $_active_school_id_ = null; }
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            if (($_active_school_id_ == $this->getAttribute($_school_, "id"))) {
                echo " selected ";
            }
            echo ">";
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "</option>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['school'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "        </select>
      </div>
    </div>
  </form>
</div>

<div class=\"col-lg-12\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Geregistreerde gebruikers</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"user-activity\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen talenten</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-talents-donut\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen vaardigheden</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-skills-donut\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Gekozen Schooladviezen</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"most-picked-schooladvices\"></div>
    </div>
  </div>
</div>

<div class=\"col-lg-4\">
  <div class=\"panel panel-primary\">
    <div class=\"panel-heading\">
      <h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i> Geslacht gebruikers</h3>
    </div>
    <div class=\"panel-body\">
        <div id=\"donut-users-gender\"></div>
    </div>
  </div>
</div>

";
    }

    // line 163
    public function block_extrajs($context, array $blocks = array())
    {
        // line 164
        echo "<script>
\$(document).ready(function(){
    Morris.Bar({
        element: 'most-picked-talents-donut',
        data: JSON.parse('";
        // line 168
        if (isset($context["most_picked_talents"])) { $_most_picked_talents_ = $context["most_picked_talents"]; } else { $_most_picked_talents_ = null; }
        echo twig_jsonencode_filter($_most_picked_talents_);
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 35,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Bar({
        element: 'most-picked-skills-donut',
        data: JSON.parse('";
        // line 185
        if (isset($context["most_picked_skills"])) { $_most_picked_skills_ = $context["most_picked_skills"]; } else { $_most_picked_skills_ = null; }
        echo twig_jsonencode_filter($_most_picked_skills_);
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 45,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Bar({
        element: 'most-picked-schooladvices',
        data: JSON.parse('";
        // line 202
        if (isset($context["most_schooladvices"])) { $_most_schooladvices_ = $context["most_schooladvices"]; } else { $_most_schooladvices_ = null; }
        echo twig_jsonencode_filter($_most_schooladvices_);
        echo "'),
        xkey: 'label',
        ykeys: ['female', 'male'],
        labels: ['Vrouw', 'Man'],
        xLabelAngle: 45,
        hideHover: 'auto',
        stacked: true,
        hoverCallback: function (index, options, content) {
            var body = content;
            var total = parseInt(this.data[index].male, 10) + parseInt(this.data[index].female, 10);
            body += \"<div class='morris-hover-point' style='color: #0b62a4'>Totaal: \"+total+\"</div>\";
            return body;
        }
    });

    Morris.Area({
        element: 'user-activity',
        data: JSON.parse('";
        // line 219
        if (isset($context["users"])) { $_users_ = $context["users"]; } else { $_users_ = null; }
        echo twig_jsonencode_filter($this->getAttribute($_users_, "created_by_day"));
        echo "'),
        xkey: 'day',
        ykeys: ['amount'],
        labels: ['hoeveelheid'],
        pointSize: 2,
        hideHover: 'auto'
      });

    Morris.Donut({
      element: 'donut-users-gender',
      data: JSON.parse('";
        // line 229
        if (isset($context["users_gender"])) { $_users_gender_ = $context["users_gender"]; } else { $_users_gender_ = null; }
        echo twig_jsonencode_filter($_users_gender_);
        echo "'),
      formatter: function (y) {
        var total = this.data[0].value + this.data[1].value;
        return Math.round((y / total * 100) * 100) / 100 + \"%\";
      }
    });
});
</script>
";
    }

    public function getTemplateName()
    {
        return "dashboard.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  323 => 229,  309 => 219,  288 => 202,  267 => 185,  246 => 168,  240 => 164,  237 => 163,  172 => 100,  153 => 98,  148 => 97,  122 => 74,  113 => 69,  87 => 46,  78 => 41,  52 => 18,  43 => 13,  32 => 4,  29 => 3,);
    }
}
