<?php

/* users/overview.html */
class __TwigTemplate_f76d35e3d18d4bd78a738896b737f9028e01a16d62860e71a20ace5e8c2ad946 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Gebruikers <small>gebruikers overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Gebruikers</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Nickname <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">School <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Geslacht <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Gemaakt op <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Talenten <i class=\"fa fa-sort\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 25
        if (isset($context["users"])) { $_users_ = $context["users"]; } else { $_users_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_users_);
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 26
            echo "                    <tr>
                        <td>
                            ";
            // line 28
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_user_, "nickname"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 31
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($_user_, "school"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <i class=\"fa fa-";
            // line 34
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo ((($this->getAttribute($_user_, "gender") == "m")) ? ("male") : ("female"));
            echo "\" style=\"color:";
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo ((($this->getAttribute($_user_, "gender") == "m")) ? ("#08004F") : ("#6D00B5"));
            echo "\"></i>
                            <p style=\"display:none\">";
            // line 35
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo ((($this->getAttribute($_user_, "gender") == "m")) ? ("male") : ("female"));
            echo "</p>
                        </td>
                        <td>
                            ";
            // line 38
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($_user_, "created_at"), "d/m/y"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 41
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(twig_sort_filter($this->getAttribute($_user_, "talents")));
            foreach ($context['_seq'] as $context["_key"] => $context["talent"]) {
                // line 42
                echo "                                 ";
                if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                if (($this->getAttribute($this->getAttribute($_talent_, "pivot"), "picked") == 1)) {
                    // line 43
                    echo "                                    ";
                    if (isset($context["talent"])) { $_talent_ = $context["talent"]; } else { $_talent_ = null; }
                    echo twig_escape_filter($this->env, $this->getAttribute($_talent_, "name"), "html", null, true);
                    echo ",
                                 ";
                }
                // line 45
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['talent'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "users/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 49,  121 => 46,  115 => 45,  108 => 43,  104 => 42,  99 => 41,  92 => 38,  85 => 35,  77 => 34,  70 => 31,  63 => 28,  59 => 26,  54 => 25,  31 => 4,  28 => 3,);
    }
}
