<?php

/* skills/overview.html */
class __TwigTemplate_cb241224509b88262eb82a16203023df22be8bb1ac0e7e7eff4bf6cb624b5f46 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>vaardigheden <small>vaardigheden overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> vaardigheden</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <p>
                <a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_new"), "html", null, true);
        echo "\" class=\"btn btn-success\">
                    <i class=\"fa fa-plus\"></i> Toevoegen
                </a>
            </p>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 30
        if (isset($context["skills"])) { $_skills_ = $context["skills"]; } else { $_skills_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_skills_);
        foreach ($context['_seq'] as $context["_key"] => $context["skill"]) {
            // line 31
            echo "                    <tr>
                        <td>
                            ";
            // line 33
            if (isset($context["skill"])) { $_skill_ = $context["skill"]; } else { $_skill_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_skill_, "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 36
            if (isset($context["skill"])) { $_skill_ = $context["skill"]; } else { $_skill_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_edit", array("id" => $this->getAttribute($_skill_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                            <a href=\"";
            // line 37
            if (isset($context["skill"])) { $_skill_ = $context["skill"]; } else { $_skill_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("skills_delete", array("id" => $this->getAttribute($_skill_, "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-trash-o\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['skill'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "skills/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 41,  83 => 37,  78 => 36,  71 => 33,  67 => 31,  62 => 30,  43 => 14,  31 => 4,  28 => 3,);
    }
}
