<?php

/* schools/delete.html */
class __TwigTemplate_2f0fd07e7f328bd99e5d18a9a43ad47f87c8782f94f13586095095b438250a5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>scholen <small>school verwijderen</small></h1>
            <ol class=\"breadcrumb\">
                <li><i class=\"fa fa-dashboard\"></i> scholen</li>
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Verwijderen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">

            ";
        // line 15
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "POST")) {
            // line 16
            echo "
            <div class=\"panel panel-success\">
                <div class=\"panel-heading\">
                <h3 class=\"panel-title\">school verwijderd!</h3>
                </div>
                <div class=\"panel-body\">
                    school: '";
            // line 22
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "' succesvol verwijderd!
                </div>
            </div>

            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_overview"), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                  <i class=\"fa fa-arrow-left\"></i> Terug
            </a>
            ";
        }
        // line 30
        echo "
            ";
        // line 31
        if (isset($context["request_method"])) { $_request_method_ = $context["request_method"]; } else { $_request_method_ = null; }
        if (($_request_method_ == "GET")) {
            // line 32
            echo "            <div class=\"panel panel-danger\">
                <div class=\"panel-heading\">
                <h3 class=\"panel-title\">school '";
            // line 34
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "' verwijderen</h3>
                </div>
                <div class=\"panel-body\">
                  Weet u zeker dat u het school: '<b>";
            // line 37
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_school_, "name"), "html", null, true);
            echo "</b>' wilt verwijderen?
                </div>
            </div>

            <form method=\"POST\" action=\"";
            // line 41
            if (isset($context["school"])) { $_school_ = $context["school"]; } else { $_school_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_delete", array("id" => $this->getAttribute($_school_, "id"))), "html", null, true);
            echo "\">
              <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("schools_overview"), "html", null, true);
            echo "\" class=\"btn btn-primary\">
                  <i class=\"fa fa-arrow-left\"></i> Nee, terug
              </a>
              <button type=\"submit\" class=\"btn btn-danger\">
                  <i class=\"fa fa-trash-o\"></i> Ja
              </button>
            </form>
            ";
        }
        // line 50
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "schools/delete.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 50,  100 => 42,  95 => 41,  87 => 37,  80 => 34,  76 => 32,  73 => 31,  70 => 30,  63 => 26,  55 => 22,  47 => 16,  44 => 15,  31 => 4,  28 => 3,);
    }
}
