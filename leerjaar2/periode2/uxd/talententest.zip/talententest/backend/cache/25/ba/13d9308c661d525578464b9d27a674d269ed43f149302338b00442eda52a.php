<?php

/* base.html */
class __TwigTemplate_25ba13d9308c661d525578464b9d27a674d269ed43f149302338b00442eda52a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'navigation' => array($this, 'block_navigation'),
            'content' => array($this, 'block_content'),
            'extrajs' => array($this, 'block_extrajs'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <base href=\"";
        // line 4
        if (isset($context["base_url"])) { $_base_url_ = $context["base_url"]; } else { $_base_url_ = null; }
        echo twig_escape_filter($this->env, $_base_url_, "html", null, true);
        echo "\" target=\"_self\">

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>Talententest Admin</title>

    <!-- Bootstrap core CSS -->
    <link href=\"css/bootstrap.css\" rel=\"stylesheet\">

    <!-- Add custom CSS here -->
    <link href=\"css/sb-admin.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"font-awesome/css/font-awesome.min.css\">
    <!-- Page Specific CSS -->
    <link rel=\"stylesheet\" href=\"http://cdn.oesmith.co.uk/morris-0.4.3.min.css\">
  </head>

  <body>

    <div id=\"wrapper\">
    ";
        // line 26
        $this->displayBlock('navigation', $context, $blocks);
        // line 52
        echo "      <div id=\"page-wrapper\">
      ";
        // line 53
        $this->displayBlock('content', $context, $blocks);
        // line 56
        echo "
      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src=\"js/jquery-1.10.2.js\"></script>
    <script src=\"js/bootstrap.js\"></script>

    <!-- Page Specific Plugins -->
    <script src=\"http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js\"></script>
    <script src=\"http://cdn.oesmith.co.uk/morris-0.4.3.min.js\"></script>
    <script src=\"js/morris/chart-data-morris.js\"></script>
<!--     <script src=\"js/flot/jquery.flot.js\"></script>
    <script src=\"js/flot/jquery.flot.pie.js\"></script>
    <script src=\"js/flot/jquery.flot.resize.js\"></script>
    <script src=\"js/flot/jquery.flot.tooltip.min.js\"></script> -->
    <script src=\"js/tablesorter/jquery.tablesorter.js\"></script>
    <script src=\"js/tablesorter/tables.js\"></script>
    <script src=\"ckeditor/ckeditor.js\"></script>
    <script type=\"text/javascript\">
        CKEDITOR.replace( 'ckeditor' );
    </script>
    ";
        // line 79
        $this->displayBlock('extrajs', $context, $blocks);
        // line 80
        echo "  </body>
</html>
";
    }

    // line 26
    public function block_navigation($context, array $blocks = array())
    {
        // line 27
        echo "      <!-- Sidebar -->
      <nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-ex1-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("dashboard"), "html", null, true);
        echo "\">Project Paspoort - Talententest Admin</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class=\"collapse navbar-collapse navbar-ex1-collapse\">
          <ul class=\"nav navbar-nav side-nav\">
            ";
        // line 43
        if (isset($context["mainmenu"])) { $_mainmenu_ = $context["mainmenu"]; } else { $_mainmenu_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_mainmenu_);
        foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
            // line 44
            echo "                <li";
            if (isset($context["menu"])) { $_menu_ = $context["menu"]; } else { $_menu_ = null; }
            if (isset($context["current_url"])) { $_current_url_ = $context["current_url"]; } else { $_current_url_ = null; }
            if (($this->env->getExtension('slim')->urlFor($this->getAttribute($_menu_, "url")) == $_current_url_)) {
                echo " class=\"active\"";
            }
            echo ">
                  <a href=\"";
            // line 45
            if (isset($context["menu"])) { $_menu_ = $context["menu"]; } else { $_menu_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor($this->getAttribute($_menu_, "url")), "html", null, true);
            echo "\"><i class=\"fa ";
            if (isset($context["menu"])) { $_menu_ = $context["menu"]; } else { $_menu_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_menu_, "icon"), "html", null, true);
            echo "\"></i> ";
            if (isset($context["menu"])) { $_menu_ = $context["menu"]; } else { $_menu_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_menu_, "title"), "html", null, true);
            echo "</a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
    ";
    }

    // line 53
    public function block_content($context, array $blocks = array())
    {
        // line 54
        echo "
      ";
    }

    // line 79
    public function block_extrajs($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "base.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 79,  157 => 54,  154 => 53,  147 => 48,  131 => 45,  122 => 44,  117 => 43,  108 => 37,  96 => 27,  93 => 26,  87 => 80,  85 => 79,  60 => 56,  58 => 53,  55 => 52,  53 => 26,  27 => 4,  22 => 1,  31 => 4,  28 => 3,);
    }
}
