<?php

/* occupations/overview.html */
class __TwigTemplate_9cc9b20d128e20abddd7205ba8bc5976429baeb6c1ffba1a6620124b7e7f279c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>Beroepen <small>beroepen overzicht</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> Beroepen</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">
            <p>
                <a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_new"), "html", null, true);
        echo "\" class=\"btn btn-success\">
                    <i class=\"fa fa-plus\"></i> Toevoegen
                </a>
            </p>
        </div>

        <div class=\"col-lg-12\">
            <div class=\"table-responsive\">
                <table class=\"table table-bordered table-hover table-striped tablesorter\">
                    <thead>
                        <tr>
                            <th class=\"header\">Naam <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Niveau <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Talent <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\">Laatst aangepast <i class=\"fa fa-sort\"></i></th>
                            <th class=\"header\"></i></th>
                        </tr>
                    </thead>
                <tbody>
                    ";
        // line 33
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["occupations"]) ? $context["occupations"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["occupation"]) {
            // line 34
            echo "                    <tr>
                        <td>
                            ";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "education_level"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "talent"), "name"), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 45
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "updated_at"), "H:i d/m/y"), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_edit", array("id" => $this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-edit\"></i></a>
                            <a href=\"";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("occupations_delete", array("id" => $this->getAttribute((isset($context["occupation"]) ? $context["occupation"] : null), "id"))), "html", null, true);
            echo "\"><i class=\"fa fa-trash-o\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['occupation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "                </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "occupations/overview.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 53,  101 => 49,  97 => 48,  91 => 45,  85 => 42,  79 => 39,  73 => 36,  69 => 34,  65 => 33,  43 => 14,  31 => 4,  28 => 3,);
    }
}
