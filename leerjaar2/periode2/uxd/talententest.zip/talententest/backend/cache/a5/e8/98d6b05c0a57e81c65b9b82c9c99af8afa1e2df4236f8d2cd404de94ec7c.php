<?php

/* login.html */
class __TwigTemplate_a5e898d6b05c0a57e81c65b9b82c9c99af8afa1e2df4236f8d2cd404de94ec7c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'navigation' => array($this, 'block_navigation'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_navigation($context, array $blocks = array())
    {
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"col-lg-6 col-lg-offset-2\">
      <form class=\"form-signin\" role=\"form\" method=\"POST\" action=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("login"), "html", null, true);
        echo "\">
        <h2 class=\"form-signin-heading\">Login</h2>
        <div class=\"form-group ";
        // line 10
        if (isset($context["error"])) { $_error_ = $context["error"]; } else { $_error_ = null; }
        if ($_error_) {
            echo " has-error ";
        }
        echo "\">
            <input type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Gebruikersnaam\" required autofocus>
        </div>
        <div class=\"form-group ";
        // line 13
        if (isset($context["error"])) { $_error_ = $context["error"]; } else { $_error_ = null; }
        if ($_error_) {
            echo " has-error ";
        }
        echo "\">
            <input name=\"password\" type=\"password\" class=\"form-control\" placeholder=\"Wachtwoord\" required>
            <p class=\"help-block\">";
        // line 15
        if (isset($context["error"])) { $_error_ = $context["error"]; } else { $_error_ = null; }
        echo twig_escape_filter($this->env, $_error_, "html", null, true);
        echo "</p>
        </div>
        <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Inloggen</button>
      </form>
    </div>

";
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 15,  54 => 13,  45 => 10,  40 => 8,  37 => 7,  34 => 6,  29 => 3,);
    }
}
