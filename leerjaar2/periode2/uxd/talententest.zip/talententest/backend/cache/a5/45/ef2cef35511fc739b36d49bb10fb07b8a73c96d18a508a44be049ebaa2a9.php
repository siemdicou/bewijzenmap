<?php

/* 404.html */
class __TwigTemplate_a545ef2cef35511fc739b36d49bb10fb07b8a73c96d18a508a44be049ebaa2a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1>404 Page Not Found <small>page was not found :(</small></h1>
            <ol class=\"breadcrumb\">
                <li class=\"active\"><i class=\"fa fa-dashboard\"></i> 404</li>
            </ol>
        </div>

        <div class=\"col-lg-12\">

        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "404.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,);
    }
}
